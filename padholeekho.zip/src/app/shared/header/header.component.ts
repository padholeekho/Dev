import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  toggleValue:boolean = false;
  error: any;
  menudata = [];
  constructor(private apiservice: ApiService) { }
  
  ngOnInit() {
        // Competitive Exam Menu 
        this.apiservice.get('/api/admin/course/level-setting/super-course/list', "").pipe(
          tap(response=>{
            console.log(response.data);
            this.menudata = Array.from(Object.keys(response.data), k=>response.data[k]);
          }),
         catchError(error => of(this.error = error))
        ).subscribe()
  }

  goDetailsPage(itemId){
    let menuId = itemId.getAttribute('data-item-id');
    //let menuId = itemId.dataset.itemId;
    console.log("Menu Id: ", menuId);
  }

  toggle() {
    this.toggleValue = !this.toggleValue ? true : false;
  }

}
