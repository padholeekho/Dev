import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PrivacyComponent } from '../privacy';

const routes: Routes = [  
  {
    path: '',
    component: PrivacyComponent,
  },
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class PrivacyRoutingModule { }
