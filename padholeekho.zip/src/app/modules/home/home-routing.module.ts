import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../home';

const routes: Routes = [  
  {
    path: '',
    component: HomeComponent
  } ,
  {
    path: '',
    redirectTo: '',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class HomeRoutingModule { }
