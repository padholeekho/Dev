export const environment = {
  production: true,
  server_url: 'https://34.93.95.64/padholeekho/public'
};
