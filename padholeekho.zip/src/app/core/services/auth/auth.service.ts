import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  isSession() {
    if (localStorage.getItem('user_Id')) {
      return true;
    }
    return false;
  }

}
