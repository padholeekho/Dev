import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';


@Component({
    selector: 'app-details',
    templateUrl: './details.component.html',
    styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

    show: boolean;
    isLoading: boolean = false;
    error: any;
    bannerData: any;
    topicList: any;
    topicListDetailslist: any;
    SAB: any;

    constructor(
        private authService: AuthService,
        private activatedRoute: ActivatedRoute,
        private apiservice: ApiService
    ) {
        this.show = this.authService.isSession();
        this.activatedRoute.params.subscribe(params => {
            if (params['course_id']) {
                console.log(params['course_id'])
                this.isLoading = true;
                // Banner And right side Card
                this.apiservice.get('/api/rest/courses/listing/sub-course', { course_id: params['course_id'] }).pipe(
                    tap(response => {
                        const sub_course_id = response.data[0].id;
                        this.bannerData = response.data[0];
                        if (sub_course_id) {
                            this.topiList(sub_course_id);
                        }
                    }),
                    finalize(() => this.isLoading = false),
                    catchError(error => of(this.error = error))
                ).subscribe()
            }
        })
    }
    

    ngOnInit() {
    }

    // Topic List

    topiList(sub_course_id) {
        this.isLoading = true;
        this.apiservice.get('/api/rest/courses/listing/course-code', { sub_course_id: sub_course_id }).pipe(
            tap(response => {
                const id = response.data[0].id;
                this.topicList = response.data
                if (id) {
                    this.topicListDetails(id);
                }
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe()
    }

    // Topic List Details >

    topicListDetails(id) {
        this.isLoading = true;
        this.apiservice.get('/api/rest/courses/listing/course-code-details', { id: id }).pipe(
            tap(response => {
                this.topicListDetailslist = response.data
                this.StudentAlsoBrought(id);
                this.conceptuallyInterrelatedCourses(id)
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe()
    }

    // Student Also Brought
    
    StudentAlsoBrought(id){
        this.isLoading = true;
        this.apiservice.get('/api/rest/courses/listing/sab-course', {sub_course_id: id}).pipe(
            tap(response => {
                this.SAB = response.data
                console.log(response)
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe()
    }

    // Conceptually Interrelated Courses

    conceptuallyInterrelatedCourses(id){
        this.isLoading = true;
        this.apiservice.get('/api/rest/courses/listing/cic-course', {sub_course_id: id}).pipe(
            tap(response => {
                this.cic = response.data
                console.log(response)
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe()
    }

    // Topic List
    topiclistslide: any = {
        loop: true,
        mouseDrag: true,
        touchDrag: true,
        pullDrag: false,
        dots: false,
        navSpeed: 700,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 2
            },
            740: {
                items: 4
            },
            940: {
                items: 4
            }
        },
        nav: true
    }

    // Student Also Brought
    studentAlsoBrought: any = {
        loop: true,
        mouseDrag: true,
        touchDrag: true,
        pullDrag: false,
        dots: false,
        navSpeed: 700,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 3
            },
            740: {
                items: 3
            },
            940: {
                items: 4
            }
        },
        nav: true
    }

    // Conceptually Interrelated Courses
    cic: any = {
        loop: true,
        mouseDrag: true,
        touchDrag: true,
        pullDrag: false,
        dots: false,
        navSpeed: 700,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 3
            },
            740: {
                items: 3
            },
            940: {
                items: 4
            }
        },
        nav: true
    } 

    // Combo Offer
    combooffer: any = {
        loop: true,
        mouseDrag: true,
        touchDrag: true,
        pullDrag: false,
        dots: false,
        navSpeed: 700,
        navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
        responsive: {
            0: {
                items: 1
            },
            400: {
                items: 2
            },
            740: {
                items: 3
            },
            940: {
                items: 4
            }
        },
        nav: true
    }

}
