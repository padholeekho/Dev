import { Component, OnInit } from '@angular/core';
import { ProfileService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css']
})
export class MyProfileComponent implements OnInit {
  isLoading: boolean = false;
  error: any;
  userinfo: any

  constructor( 
    private profileServices: ProfileService,
    private router: Router
  ) { }

  ngOnInit() {
    let userId = localStorage.getItem('user_Id')
    this.isLoading = true;
    this.profileServices.myprofileApi(userId).pipe(
      tap(response =>{
         this.userinfo = response.data;
      }),
    finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
    ).subscribe();
  }

  changePassword(){
    this.router.navigate(['user/myProfile/changePassword'])
  }
  updateProfile(){
    this.router.navigate(['user/myProfile/updateProfile'])
  }

}
