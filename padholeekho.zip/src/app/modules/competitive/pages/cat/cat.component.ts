import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../../../core/services';
import { tap, catchError, finalize } from 'rxjs/operators';
import { of } from 'rxjs';



@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {
  homeForm: FormGroup;
  submitted = false;
  isLoading: boolean = false;
  menuId: any;
  error: any;
  data: any;
  tablist: any[];
  tabdata: any[];
  response: any;
  sectionTwo_data: any[];
  sectionTwo_data_res: any;

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private apiservice: ApiService
  ) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required],
    })

    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.isLoading = true;
        this.apiservice.get('/api/rest/courses/listing/super-course', { id: params['id'] }).pipe(
          tap(response => {
            const data = Array.from(Object.keys(response.data), k => response.data[k]);
            this.data = data[0]
          }),
          finalize(() => this.isLoading = false),
          catchError(error => of(this.error = error))
        ).subscribe()
      }
    });
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }

  }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.isLoading = true;
      if (params['id']) {
        this.apiservice.get('/api/admin/course/level-setting/master-course/list', { super_course_id: params['id'] }).pipe(
          tap(response => {
            this.tablist = Array.from(Object.keys(response.data), k => response.data[k]);
            this.tabDetails(this.tablist[0].id);
          }),
          finalize(() => this.isLoading = false),
          catchError(error => of(this.error = error))
        ).subscribe()
      }
    });
  }


  tabDetails(id) {
    // First Section
    this.isLoading = true;
    this.apiservice.get('/api/rest/courses/listing/master-course', { id: id }).pipe(
    tap(response => {
      this.response = response.status;
      const tabdata = Array.from(Object.keys(response.data), k => response.data[k]);
      console.log(tabdata);
      this.tabdata = tabdata[0];
    }),
    finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
  ).subscribe()

    // Section Section
    this.isLoading = true;
    this.apiservice.get('/api/rest/courses/listing/course', {master_course_id: id}).pipe(
    tap(response => {
      this.sectionTwo_data_res = response.status
      this.sectionTwo_data = Array.from(Object.keys(response.data), k=>response.data[k]);
    }),
    finalize(() => this.isLoading = false),
    catchError(error => of(this.error = error))
  ).subscribe()
  }

  courseDetails(id){
   this.router.navigate(['details', {course_id:id}])
  }

  addtocart(){
    alert('Add to cart')
  }

}