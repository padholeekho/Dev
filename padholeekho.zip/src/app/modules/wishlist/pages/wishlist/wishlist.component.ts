import { Component, OnInit } from '@angular/core';
import { WishlistService } from '../../services/wishlist.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {
  isLoading: boolean = false;
  wishlist: any;
  error: any;

  constructor(private wishlistservice: WishlistService, private router:Router) {
    
  }

  // Get Wishlist Details
  getwishlist(){
    this.isLoading = true
    let wishlistParam = {
      user_id: localStorage.getItem('user_Id'),
    }
    this.wishlistservice.getwistListApi(wishlistParam).pipe(
      tap(response => { 
        this.wishlist = response.status == "success" ? response.data.content : [];
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }
 
  // Move To Cart

  movetoCart(wishlist_id){
    this.isLoading = true;
    let wishlistId = {id:wishlist_id}
    this.wishlistservice.movetoCartApi(wishlistId).pipe(
      tap(response =>{
        if(response.status == "success"){
          this.getwishlist()
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()
  }

  // Remove from Wishlist
  removeWishlist(wishlist_id){
    this.isLoading = true;
    let wishlistId = {id:wishlist_id}
    this.wishlistservice.removeWishListApi(wishlistId).pipe(
      tap(response =>{
        if(response.status == "success"){
          this.getwishlist()
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()
  }

  getActualPrice(){
    return this.wishlist.map(t => t.actual_price).reduce((a,value) => a + value, 0)
  }

  movetoCartpage(){
    this.router.navigate(['/user/cart'])
  }

  continueShoping(){
    this.router.navigate(['/user/home'])
  }

  ngOnInit() {
    this.getwishlist()
  }

}
