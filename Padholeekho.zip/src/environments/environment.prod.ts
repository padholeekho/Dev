export const environment = {
  production: true,
  server_url: 'https://142.4.14.136/backend/public/'
};
