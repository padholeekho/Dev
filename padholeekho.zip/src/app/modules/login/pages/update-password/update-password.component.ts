import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MustMatch } from 'src/app/shared';
import { Router } from '@angular/router';

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.css']
})
export class UpdatePasswordComponent implements OnInit {
  updatePasswordForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean = false;
  show_button: Boolean = false;
  show_eye: Boolean = false;

  constructor(private formBuilder: FormBuilder,private router: Router,) {
    this.updatePasswordForm = this.formBuilder.group({
      password: ["", [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validator: MustMatch('password', 'confirmPassword') });
  }
  get f() { 
    return this.updatePasswordForm.controls; 
  }

  ngOnInit() {
  }
  showPassword() {
    this.show_button = !this.show_button;
    this.show_eye = !this.show_eye;
  }
  updatePassword(){
    this.submitted = true; 
    if (this.updatePasswordForm.invalid) {
      return;
    }
    this.isLoading = true;
  }

  goRegister(){
    this.router.navigate(['auth/register'])
  }

}
