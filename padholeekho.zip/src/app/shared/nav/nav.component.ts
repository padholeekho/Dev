import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProfileService } from 'src/app/modules/my-profile/services';
import { tap } from 'rxjs/operators';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.css']
})
export class NavComponent implements OnInit {
  toggleValue: boolean = false;
  username: any;

  constructor(
    private router: Router,
    private profileServices: ProfileService,
    ) { }

  ngOnInit() {
    let userId = localStorage.getItem('user_Id')
    this.profileServices.myprofileApi(userId).pipe(
      tap(response =>{
        this.username = response.data.name;
      }),
    ).subscribe();
  }

  toggle() {
    this.toggleValue = !this.toggleValue ? true : false;
  }

  logout(){
    localStorage.removeItem('user_Id');
    this.router.navigate(['auth/home']);
  }

}
