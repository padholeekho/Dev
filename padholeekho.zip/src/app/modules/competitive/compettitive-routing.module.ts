import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CatComponent } from './pages/cat/cat.component';

const routes: Routes = [  
  {
    path: 'cat',
    component: CatComponent,
  },
  {
    path: '',
    redirectTo: 'cat',
    pathMatch: 'full'
  }, 
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CompettitiveRoutingModule { }
