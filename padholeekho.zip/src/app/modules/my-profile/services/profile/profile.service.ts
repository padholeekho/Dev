import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  constructor( private apiservices: ApiService ) { }

  // Profile Details API -------------------------------------!

  myprofileApi(userId):Observable<any> {
    console.log(userId);
    return this.apiservices.get('/api/rest/authentication/signin/profile', {user_id:userId} )
  }  
}
