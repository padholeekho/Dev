import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

declare var $: any;

interface AfterViewInit {
  ngAfterViewInit(): void
}

@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrls: ['./testimonial.component.css']
})
export class TestimonialComponent implements OnInit {
  error: any;
  constructor( private apiservice: ApiService ) { }

  ngOnInit() {
    // Testimial 
    this.apiservice.get('/api/admin/content-setting/list', 'testimonials').pipe(
      tap(response=>{
        console.log(response)
      }),
     catchError(error => of(this.error = error))
    ).subscribe()

    // Blog
    this.apiservice.get('/api/admin/content-setting/list', 'blog').pipe(
      tap(response=>{
        console.log(response)
      }),
     catchError(error => of(this.error = error))
    ).subscribe()
  }

  ngAfterViewInit() {
    $("#testimonial-slider").owlCarousel({
      autoplay: false,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 2
        },

        1024: {
          items: 2
        },

        1366: {
          items: 2
        }
      }
    });

    $("#blog-slider").owlCarousel({
      autoplay: false,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 2
        },

        1024: {
          items: 3
        },

        1366: {
          items: 3
        }
      }
    });
  }

}
