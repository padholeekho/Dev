import { Injectable } from '@angular/core';
import { ApiService } from 'src/app/core/services';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  constructor(private apiservice: ApiService) { }

  cartListApi(data){
    this.apiservice.get('/api/rest/cart/list', data)
  }
}
