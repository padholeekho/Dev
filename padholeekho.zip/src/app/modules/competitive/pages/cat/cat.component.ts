import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {
  homeForm:FormGroup;
  submitted = false;
  constructor(private formBuilder: FormBuilder) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required,Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required ],
    })
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm(){
    this.submitted = true;

    // stop here if form is invalid
    if (this.homeForm.invalid) {
        return;
    }

  }

  ngOnInit() {
  }

}
