import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HomeService } from '../../services/home/home.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

declare var $: any;

interface AfterViewInit {
  ngAfterViewInit(): void
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit, OnInit {

  homeForm: FormGroup;
  submitted = false; 
  error: any;
  isLoading: boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private homeService: HomeService
    ) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required],
    })
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }

  }

  ngOnInit() { 
    // Recent Courses
    this.homeService.recentCoursesApi().pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();

    // Combo Offer
    this.homeService.comboOfferApi().pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()

    // section 4 
    this.homeService.section_4_Api().pipe(
      tap(response =>{
        console.log(response)
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      }),
    ).subscribe()

    // Upcoming Courses
    this.homeService.upcomingCoursesApi().pipe(
      tap(response=>{
        console.log(response)
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      })
    ).subscribe()
  }

  ngAfterViewInit() {

    $("#carousel").owlCarousel({
      autoplay: true,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 3
        },

        1024: {
          items: 5
        },

        1366: {
          items: 5
        }
      }
    });

    $("#r-course").owlCarousel({
      autoplay: true,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 3
        },

        1024: {
          items: 4
        },

        1366: {
          items: 4
        }
      }
    });

    $("#u-course").owlCarousel({
      autoplay: true,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 3
        },

        1024: {
          items: 4
        },

        1366: {
          items: 4
        }
      }
    });

    $("#c-offer").owlCarousel({
      autoplay: false,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 2
        },

        1024: {
          items: 3
        },

        1366: {
          items: 3
        }
      }
    });

  }

}
