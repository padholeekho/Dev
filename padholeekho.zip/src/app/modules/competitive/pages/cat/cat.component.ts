import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-cat',
  templateUrl: './cat.component.html',
  styleUrls: ['./cat.component.css']
})
export class CatComponent implements OnInit {
  homeForm: FormGroup;
  submitted = false;
  menuId: any;
  error: any;
  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private apiservice: ApiService
  ) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required],
    })

    this.activatedRoute.params.subscribe(params => {
      if (params['id']) {
        this.apiservice.get('/api/rest/courses/listing/super-course', params['id']).pipe(
          tap(response => {
            console.log(response)
          }),
          catchError(error => of(this.error = error))
        ).subscribe()
      } 
    });
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }

  }

  ngOnInit() {
  }

}
