import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OtpService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';

declare let $: any;

interface AfterViewInit {
  ngAfterViewInit(): void
}

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements AfterViewInit, OnInit {
  otpForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean;
  error: any; 
  paramValue = {};

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private otpService: OtpService,
    private formBuilder: FormBuilder
  ) {
    this.activatedRoute.params.subscribe(params => {
      if (params.user_id && params.pageName) {
        this.paramValue = params;  
      } else {
        this.router.navigate(['auth/home']);
      }

    });
    this.otpForm = this.formBuilder.group({
      oneInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      twoInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      threeInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      fourInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]]
    })
  }

  get f() { return this.otpForm.controls; }

  ngOnInit() {
  }

  // Register & Forget OTP Function

  verifyOtp() {
    this.submitted = true;
    if (this.otpForm.invalid) {
      return;
    }
    let passData = {}; 
    passData[`${this.paramValue['pageName']}_exp`] = `${this.otpForm.value.oneInputOtp + this.otpForm.value.twoInputOtp + this.otpForm.value.threeInputOtp + this.otpForm.value.fourInputOtp}`;
    this.paramValue['pageName'] == 'register' ? passData['temp_user_id'] = this.paramValue['user_id'] : passData['user_id'] = this.paramValue['user_id'];
    this.otpService.verifyOtpApi(passData, this.paramValue['pageName']).pipe(
      tap(response => {
        console.log(response);
        if (response.status == 'success') {
          if (this.paramValue['pageName'] == 'register') {
            this.router.navigate(['/auth/login']);
          } else {
            alert('Create Update Password component')
          }
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  } 

  resendOtp() { 
    this.otpService.resendOtpApi({ 'temp_user_id' : this.paramValue['user_id'] }).pipe(
      tap(response => {
        console.log(response);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  ngAfterViewInit() {
    $(function () {
      'use strict';

      let body = $('body');

      function goToNextInput(e) {
        let key = e.which,
          t = $(e.target),
          sib = t.next('input');

        if (key != 9 && (key < 48 || key > 57)) {
          e.preventDefault();
          return false;
        }

        if (key === 9) {
          return true;
        }

        if (!sib || !sib.length) {
          sib = body.find('input').eq(0);
        }
        sib.select().focus();
      }

      function onKeyDown(e) {
        let key = e.which;

        if (key === 9 || (key >= 48 && key <= 57)) {
          return true;
        }

        e.preventDefault();
        return false;
      }

      function onFocus(e) {
        $(e.target).select();
      }

      body.on('keyup', 'input', goToNextInput);
      body.on('keydown', 'input', onKeyDown);
      body.on('click', 'input', onFocus);

    })
  }

}
