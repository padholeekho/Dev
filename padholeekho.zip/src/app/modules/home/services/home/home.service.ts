import { Injectable } from '@angular/core';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor( private apiService: ApiService ) {}

  recentCoursesApi(){
    return this.apiService.get('/api/rest/courses/listing/recent-course', "")
  }

  comboOfferApi(){
    return this.apiService.get('/api/rest/courses/listing/combo-offer', "")
  }

  section_4_Api(){
    return this.apiService.get('/api/admin/content-setting/list', "")
  }

  upcomingCoursesApi(){
    return this.apiService.get('/api/admin/course/upcoming-course/list', "")
  }

}
