import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HomeService } from '../../services/home/home.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

declare var $: any;

interface AfterViewInit {
  ngAfterViewInit(): void
}

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements AfterViewInit, OnInit {

  homeForm: FormGroup;
  submitted = false; 
  error: any;
  isLoading: boolean = false;
  RecentCourses_data: any[];
  comboOffer_data: any[];
  freeLession_data: any[];
  upcommingCourse_data: any[];

  constructor(
    private formBuilder: FormBuilder,
    private homeService: HomeService
    ) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required],
    })
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }

  }

  ngOnInit() { 
    this.isLoading = true
    // Recent Courses
    this.homeService.recentCoursesApi().pipe(
      tap(response =>{
        this.RecentCourses_data = Array.from(Object.keys(response.data), k=>response.data[k]);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();

    // Combo Offer
    this.homeService.comboOfferApi().pipe(
      tap(response =>{
        this.comboOffer_data = Array.from(Object.keys(response.data), k=>response.data[k]);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()

    // section 4 
    this.homeService.section_4_Api().pipe(
      tap(response =>{
        this.freeLession_data = Array.from(Object.keys(response.data), k=>response.data[k]);
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      }),
    ).subscribe()

    // Upcoming Courses
    this.homeService.upcomingCoursesApi().pipe(
      tap(response=>{
        this.upcommingCourse_data = Array.from(Object.keys(response.data), k=>response.data[k]);
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      })
    ).subscribe()
  }
//Recent course
  recentcourse: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  }

// Combo Offer 
  ComboOffer: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },
    nav: true
  }

// Upcoming Courses
upcomingCourses: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  }

  ngAfterViewInit() {

    $("#carousel").owlCarousel({
      autoplay: true,
      lazyLoad: true,
      loop: true,
      margin: 20,
      responsiveClass: true,
      autoHeight: true,
      autoplayTimeout: 7000,
      smartSpeed: 800,
      nav: true,
      dots: false,
      navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
      responsive: {
        0: {
          items: 1
        },

        600: {
          items: 3
        },

        1024: {
          items: 5
        },

        1366: {
          items: 5
        }
      }
    });

  }

}
