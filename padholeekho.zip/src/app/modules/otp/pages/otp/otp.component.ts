import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { OtpService } from '../../services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'; 

declare var $: any;

interface AfterViewInit {
  ngAfterViewInit(): void
}

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements AfterViewInit, OnInit {
  otpForm: FormGroup;
  submitted: boolean = false;
  isLoading: boolean;
  error: any;
  data = {};

  constructor(
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private otpService: OtpService,
    private formBuilder: FormBuilder
  ) {
    this.activatedRoute.params.subscribe(params => {
      if (params) {
        this.data['register_exp'] = params.registerExp;
        this.data['temp_user_id'] = params.tempUserId;
        this.data['name'] = params.name;
        console.log(this.data);
      }
    });
    this.otpForm = this.formBuilder.group({
      oneInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      twoInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      threeInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]],
      fourInputOtp: [null, [Validators.required, Validators.min(0), Validators.max(9), Validators.minLength(1), Validators.maxLength(1), Validators.pattern(/^[0-9]+$/)]]
    })
  }

  get f() { return this.otpForm.controls; }

  ngOnInit() {
  }

  verifyOtp() {
    this.submitted = true;
    if (this.otpForm.invalid) {
      return;
    }
    console.log(this.data);
    this.otpService.verifyOtpApi(this.data).pipe(
      tap(response => {
        console.log(response);
        if (response.status == 'success') {
          this.router.navigate(['login']);
        }
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  resendOtpApi() {
    delete this.data['register_exp'];
    this.otpService.resendOtpApi(this.data).pipe(
      tap(response => {
        console.log(response);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();
  }

  ngAfterViewInit(){
    $(function() {
      'use strict';
    
      var body = $('body');
    
      function goToNextInput(e) {
        var key = e.which,
          t = $(e.target),
          sib = t.next('input');
    
        if (key != 9 && (key < 48 || key > 57)) {
          e.preventDefault();
          return false;
        }
    
        if (key === 9) {
          return true;
        }
    
        if (!sib || !sib.length) {
          sib = body.find('input').eq(0);
        }
        sib.select().focus();
      }
    
      function onKeyDown(e) {
        var key = e.which;
    
        if (key === 9 || (key >= 48 && key <= 57)) {
          return true;
        }
    
        e.preventDefault();
        return false;
      }
      
      function onFocus(e) {
        $(e.target).select();
      }
    
      body.on('keyup', 'input', goToNextInput);
      body.on('keydown', 'input', onKeyDown);
      body.on('click', 'input', onFocus);
    
    })
  }

}
