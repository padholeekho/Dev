import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent, NavComponent, DetailsComponent, PnfComponent} from './shared';
import { moduleRoutes } from './shared';
import { AuthGuard } from './core';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'auth/home',
    pathMatch: 'full'
  },
  { 
    path: 'auth',   
    component: HeaderComponent,
    children: moduleRoutes
  }, 
  {
    path: 'user',
    component: NavComponent,
    canActivate: [AuthGuard],
    children: moduleRoutes
  },  
  {
    path: 'details', 
    component: DetailsComponent 
  },
  {
    path: 'pageNotFound', 
    component: PnfComponent 
  },
  { 
    path: '**', 
    redirectTo: 'pageNotFound', 
    pathMatch: 'full' 
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
