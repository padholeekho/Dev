import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from '../../../../core/services';

@Injectable({
  providedIn: 'root'
})
export class EnquiryService {

  constructor( private apiservice: ApiService) { }
  enquiryApi(data): Observable<any> {
    return this.apiservice.post('/api/admin/enquiry/store', data)
  }
  preparationDropdownApi(): Observable<any>{
    return this.apiservice.get('/api/admin/course/level-setting/super-course/list', '')
  }
}
