import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HomeService } from '../../services/home/home.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { SupportService } from 'src/app/modules/support/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  homeForm: FormGroup;
  submitted = false; 
  error: any;
  isLoading: boolean = false;
  RecentCourses_data: any[];
  comboOffer_data: any[];
  freeLession_data: any[];
  upcommingCourse_data: any[];
  dropDownList: any[];

  constructor(
    private formBuilder: FormBuilder,
    private homeService: HomeService,
    private supportService: SupportService,
    private router: Router,
    ) {
    this.homeForm = this.formBuilder.group({
      name: ['', Validators.required],
      email: ["", [Validators.required, Validators.email]],
      phone: [null, [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      super_course_id: ["", Validators.required],
    })
  }

  get f() {
    return this.homeForm.controls;
  }

  submitHomeForm() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.homeForm.invalid) {
      return;
    }
    this.isLoading = true
    this.homeService.freeLessonApi(this.homeForm.value).pipe(
      tap(response =>{
        console.log(response)
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()

  }

  addToCart(entity_type, entity_id){
    let addtocartParam = {
      user_id: localStorage.getItem('user_Id'),
      entity_id: entity_id,
      entity_type: entity_type 
    }
    this.isLoading = true;
    if (localStorage.getItem('user_Id')) {
      this.homeService.addToCartApi(addtocartParam).pipe(
        tap(response =>{
          console.log(response)
        }),
        finalize(()=>this.isLoading = false),
        catchError(error => of(this.error = error))
      ).subscribe()
    } else {
      this.router.navigate(['auth/login'])
    }
  }

  ngOnInit() { 
    this.isLoading = true
    // Recent Courses
    this.homeService.recentCoursesApi().pipe(
      tap(response =>{
        this.RecentCourses_data = Array.from(Object.keys(response.data), k=>response.data[k]);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe();

    // Combo Offer
    this.homeService.comboOfferApi().pipe(
      tap(response =>{
        this.comboOffer_data = Array.from(Object.keys(response.data), k=>response.data[k]);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()

    // section 4 
    this.homeService.section_4_Api().pipe(
      tap(response =>{
        this.freeLession_data = Array.from(Object.keys(response.data), k=>response.data[k]);
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      }),
    ).subscribe()

    // Upcoming Courses
    this.homeService.upcomingCoursesApi().pipe(
      tap(response=>{
        this.upcommingCourse_data = Array.from(Object.keys(response.data), k=>response.data[k]);
        finalize(() => this.isLoading = false),
        catchError(error => of(this.error = error))
      })
    ).subscribe()

    // Free Lessoin Dropwown List
    this.supportService.preparationDropdownApi().pipe(
      tap(response =>{
        this.dropDownList = Array.from(Object.keys(response.data), k=>response.data[k]);
      }),
      finalize(() => this.isLoading = false),
      catchError(error => of(this.error = error))
    ).subscribe()

  }
//Recent course
  recentcourse: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  }

// Combo Offer 
  ComboOffer: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 3
      }
    },
    nav: true
  }

// Upcoming Courses
  upcomingCourses: any = {
    loop: true,
    mouseDrag: true,
    touchDrag: true,
    pullDrag: false,
    dots: false,
    navSpeed: 700,
    navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
    responsive: {
      0: {
        items: 1
      },
      400: {
        items: 2
      },
      740: {
        items: 3
      },
      940: {
        items: 4
      }
    },
    nav: true
  }

}
