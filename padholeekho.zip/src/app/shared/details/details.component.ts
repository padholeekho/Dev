import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/core/services';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

declare let $: any;

@Component({
    selector: 'app-details',
    templateUrl: './details.component.html',
    styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

    show: boolean;
    isLoading: boolean = false;
    error: any;
    sub_course_id: any;

    constructor(
        private authService: AuthService,
        private activatedRoute: ActivatedRoute,
        private apiservice: ApiService
        ) {
        this.show = this.authService.isSession();
        this.activatedRoute.params.subscribe(params => {
            if(params['course_id']){
                console.log(params['course_id'])
                this.isLoading = true;
                // Banner And right side Card
                this.apiservice.get('/api/rest/courses/listing/sub-course', {course_id: params['course_id']}).pipe(
                    tap(response=>{
                        console.log(response.data[0].id)
                        this.sub_course_id = response.data[0].id
                    }),
                    finalize(() => this.isLoading = false),
                    catchError(error => of(this.error = error))
                ).subscribe()
            }
        })
    }

    ngOnInit() {
        console.log(this.sub_course_id)
        // Topic List
        this.apiservice.get('/api/rest/courses/listing/course-code', {sub_course_id: this.sub_course_id}).pipe(
            tap(response=>{
                console.log(response)
            }),
            finalize(() => this.isLoading = false),
            catchError(error => of(this.error = error))
        ).subscribe()


        $("#student-course").owlCarousel({
            autoplay: true,
            lazyLoad: true,
            loop: true,
            margin: 20,
            responsiveClass: true,
            autoHeight: true,
            autoplayTimeout: 7000,
            smartSpeed: 800,
            nav: true,
            dots: false,
            navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
            responsive: {
                0: {
                    items: 1
                },

                600: {
                    items: 3
                },

                1024: {
                    items: 4
                },

                1366: {
                    items: 4
                }
            }
        });
        $("#concept-course").owlCarousel({
            autoplay: true,
            lazyLoad: true,
            loop: true,
            margin: 20,
            responsiveClass: true,
            autoHeight: true,
            autoplayTimeout: 7000,
            smartSpeed: 800,
            nav: true,
            dots: false,
            navText: ['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
            responsive: {
                0: {
                    items: 1
                },

                600: {
                    items: 3
                },

                1024: {
                    items: 4
                },

                1366: {
                    items: 4
                }
            }
        });
    }

}
