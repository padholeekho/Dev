import { Component, OnInit } from '@angular/core';
import { CartService } from '../../servises/cart/cart.service';
import { tap, finalize, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  isLoading: boolean = false;
  error: any;

  constructor(private cartservice: CartService) { }

  ngOnInit() {

    // Cart List
    this.isLoading = true
    let cartlistParam = {
      user_id: localStorage.getItem('user_Id'),
    }
    // this.cartservice.cartListApi(cartlistParam).pipe(
    //   tap(response =>{
    //     console.log(response)
    //   }),
    //   finalize(() => this.isLoading = false),
    //   catchError(error => of(this.error = error))
    // ).subscribe();
  }

}
