/* ......All Register Service Export Features....... */ 
export * from '../services/register/register.service';