import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services';
import { tap, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
  toggleValue:boolean = false;
  error: any;
  menudata = [];

  constructor(private apiservice: ApiService, private router: Router,) { }
  
  ngOnInit() {
        // Competitive Exam Menu 
        this.apiservice.get('/api/admin/course/level-setting/super-course/list', '').pipe(
          tap(response=>{
            this.menudata = Array.from(Object.keys(response.data), k=>response.data[k]);
            console.log(response.data[0].id);
          }),
         catchError(error => of(this.error = error))
        ).subscribe()
  }

  goDetailsPage(id){
    this.router.navigate(['auth/competitive/cat', {id:id}]);
  }

  toggle() {
    this.toggleValue = !this.toggleValue ? true : false;
  }

}
